﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NameAndAge
{
    class Program
    {
        static void Main(string[] args)
        {
            String firstName = "Mark";
            Char lastInitial = 'L';
            String game = "Tetris";
            byte age = 15;

            Console.WriteLine("My name is " + firstName + " " + lastInitial + ". I am " + age + " years old and my favorite video game is " + game + ".");

            firstName = "Ethan";
            lastInitial = 'S';
            game = "Overwatch";
            age = 15;

            Console.WriteLine("My name is " + firstName + " " + lastInitial + ". I am " + age + " years old and my favorite video game is " + game + ".");
        }
    }
}
