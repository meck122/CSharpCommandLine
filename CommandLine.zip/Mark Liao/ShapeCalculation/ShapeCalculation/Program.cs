﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeCalculation
{
    class Program
    {
        static void Main(string[] args)
        {
            float answer;
            float radius;
            float length;
            float width;

            string shapeToCalc;
            Console.WriteLine("Which shape would you like to calculate? (Circle, Rectangle, Triangle, Square)");
            shapeToCalc = Console.ReadLine();

            if(shapeToCalc.ToUpper() == "CIRCLE")
            {
                radius = doRadius();
                Console.WriteLine("The area of the circle is " + (radius * Math.PI * Math.PI) + " units.");
                Console.WriteLine("The circumference of the circle is " + (radius * 2 * Math.PI) + " units.");
            }else
            if (shapeToCalc.ToUpper() == "RECTANGLE")
            {
                length = doLength();
                width = doWidth();
                Console.WriteLine("The area of the rectangle is " + (length * width) + " units.");
                Console.WriteLine("The perimeter of the rectangle is " + (length * 2 + width * 2) + " units.");
            }else
            if (shapeToCalc.ToUpper() == "SQUARE")
            {
                length = doLength();
                Console.WriteLine("The area of the square is " + (length * length) + " units.");
                Console.WriteLine("The perimeter of the sqaure is " + length * 4 + " units.");
            }else
            if (shapeToCalc.ToUpper() == "TRIANGLE")
            {
                length = doLength();
                width = doWidth();
                Console.WriteLine("The area of the triangle is " + (.5 * length * width) + " units.");
            }

        }

        static float doLength() {
            Console.WriteLine("Length?");
            return float.Parse(Console.ReadLine());
        }

        static float doWidth()
        {
            Console.WriteLine("Width?");
            return float.Parse(Console.ReadLine());
        }

        static float doRadius()
        {
            Console.WriteLine("Radius?");
            return float.Parse(Console.ReadLine());
        }

    }
}
