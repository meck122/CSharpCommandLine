﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberGuesser
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();
            string fileName = "randomnumber.txt";
            TextWriter tw = new StreamWriter(fileName);
            //writes into file
            tw.WriteLine(rand.Next(1, 101));

            //closes file
            tw.Close();

            //if files exists do this:
            if (File.Exists(fileName))
            {
                TextReader tr = new StreamReader(fileName);
                //reads file and put value into num
                int num = Convert.ToInt32(tr.ReadLine());
                tr.Close();

                int numOfGuesses = 0;
                int guess = 0;
                do
                {
                    Console.WriteLine("Guess a number 1-100");
                    //user input into 'guess'
                    guess = Convert.ToInt32(Console.ReadLine());

                    //increments numOfGuesses
                    numOfGuesses++;

                    //checks number
                    if(guess < num)
                    {
                        Console.WriteLine("Your guess is too low");
                    }else if(guess > num){
                        Console.WriteLine("Your guess is too high");
                    }else //if correct
                    {
                        Console.WriteLine("You are correct! My number was "+ num + ". It took " + numOfGuesses + " guesses." );
                    }
                    
                } while (guess != num);
            }else
            {
                Console.WriteLine("File "+ fileName + " does not exist.");
            }
        }
    }
}
