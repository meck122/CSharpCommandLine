﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops
{
    class Program
    {
        static void Main(string[] args)
        {
            int totalScore = 0;
            int input = 0;
            int highScore = 99;
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine("Enter Score for Level " + i + ":");
                input = int.Parse(Console.ReadLine());
                while (input > 100 || input < 1) 
                {
                    Console.WriteLine("Invalid Input. Try Again.");
                    Console.WriteLine("Enter Score for Level " + i + ":");
                    input = int.Parse(Console.ReadLine());
                } 
                totalScore += input;
            }
            if (totalScore > highScore)
            {
                Console.WriteLine("You beat the high score with a score of: " + totalScore);
            }
            else if (totalScore == highScore)
            {
                Console.WriteLine("You dide the high score with a score of: " + totalScore);
            }
        }
    }
}
