﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileSaving
{
    class Program
    {
        static void Main(string[] args)
        {
            string text;
            Random r = new Random();
            if (File.Exists("MyNumber.txt"))
            {
                TextWriter tw = new StreamWriter("MyNumber.txt");
                //TextReader tr = new StreamReader("MyNumber.txt");
                for (int i = 0; i < 100; i++)
                {
                    tw.WriteLine(r.Next(1, 101));
                    //tw.WriteLine(r.Next(1, 3));
                }

                tw.Close();
                TextReader tr = new StreamReader("MyNumber.txt");
                //tr.read
                text = tr.ReadToEnd();
                Console.Write(text);
                tr.Close();
            }
        }
    }
}
