﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your character's name:");
            string name = Console.ReadLine();

            Console.WriteLine("Enter " + name + "'s Level:");
            float level = float.Parse(Console.ReadLine());

            Console.WriteLine("Enter " + name + "'s Strength:");
            float strength = float.Parse(Console.ReadLine());

            Console.WriteLine("Enter " + name + "'s Defense:");
            float defense = float.Parse(Console.ReadLine());

            Console.WriteLine("Enter " + name + "'s Weapon Strength:");
            float wStrength = float.Parse(Console.ReadLine());

            Console.WriteLine("Enter " + name + "'s Armor Strength:");
            float aStrength = float.Parse(Console.ReadLine());

            Console.WriteLine("Enter " + name + "'s Speed:");
            float speed = float.Parse(Console.ReadLine());

            Console.WriteLine("Enter " + name + "'s Health Points:");
            float health = float.Parse(Console.ReadLine());

            Console.WriteLine("Total Attack Points: " + (strength + wStrength + level / 5));
            Console.WriteLine("Total Defense Points: " + (defense + aStrength + level / 5));
            Console.WriteLine("Total Speed: " + (speed + level/5 - aStrength/5));
            Console.WriteLine("Total Health: " + (health + level / 2));
        }
    }
}
