﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace AdventureGame
{
    class Program
    {
        static void Main(string[] args)
        {

            string input = "";
            bool dead = true;
            
            Console.WriteLine("This is a story that changes based on the choices you make.");
            Thread.Sleep(3000);
            Console.WriteLine("Good luck.");
            Thread.Sleep(5000);
            Console.WriteLine("\nTurning the corner into your driveway, you notice the swaying of the trees.");
            Thread.Sleep(4000);
            Console.WriteLine("You don't give much attention to it, yet then you notice a slight rumble in your car.");
            Thread.Sleep(4000);
            Console.WriteLine("A tall tree falls onto the house across the street. Panic arises, and two kids run out of the front door into the empty street.");
            Thread.Sleep(4000);
            Console.WriteLine("The ground shakes harder, and you know the decisions you make will determine the chances of your survival.");
            Thread.Sleep(4000);

            while (dead)
            {
                dead = false;
                Console.WriteLine("\n\nThe game starts here. Input A or B depending on what choice you want to make.");
                Thread.Sleep(4000);
                Console.Write("\n(A) You jump out of the car immediately. (B) You reverse the car to drive out of the neighborhood.");
                input = Console.ReadLine();
                if(input.ToUpper() == "A")
                {
                    Console.WriteLine("\nA tree crushes your car as you close the door. The kids across the street start screaming for their parents.");
                    Thread.Sleep(4000);
                    Console.Write("\n(A) You enter your house. (B) You run to the middle of the street.");
                    input = Console.ReadLine();
                    if (input.ToUpper() == "B")
                    {
                        Console.WriteLine("\nYour house crumbles right in front of your eyes. You are happy that you have good house insurance.");
                        Thread.Sleep(4000);
                        Console.Write("\n(A) You run toward the church because its walls are brick. (B) You run out of the neighborhood, but keeping to the middle of the road.");
                        input = Console.ReadLine();
                        if (input.ToUpper() == "A")
                        {
                            Console.WriteLine("\nYou die on your way to the church getting run over by another person.");
                            dead = true;
                            Thread.Sleep(4000);
                        }
                        else
                        {
                            Console.WriteLine("\nYou trip over a ladybug and die breaking your neck.");
                            dead = true;
                            Thread.Sleep(4000);
                        }
                    }
                    else
                    {
                        Console.WriteLine("\nThe house falls and it crushes you.");
                        dead = true;
                        Thread.Sleep(4000);
                    }
                }
                else
                {
                    Console.WriteLine("\nYou were crushed by a tree while you were in your car.");
                    dead = true;
                    Thread.Sleep(4000);
                }

            }
        }
    }
}
