﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysAgain
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();
            int[] combination = {rand.Next(0,10), rand.Next(0, 10), rand.Next(0, 10), rand.Next(0, 10)};
            int[] combinationEntered = new int[4];
            while (true)
            {
                for (int i = 0; i < combinationEntered.Length; i++)
                {
                    Console.Write("Enter number:");
                    int input = int.Parse(Console.ReadLine());
                    if(input >= 0 && input <= 9)
                    {
                        combinationEntered[i] = input;
                    }
                    else
                    {
                        i--;
                        Console.WriteLine("Invalid!");
                    }
                }
                if (isCorrect(combination, combinationEntered))
                {
                    Console.WriteLine("You are correct!");
                }
                else
                {
                    Console.WriteLine("You are wrong. You got " + numCorrect(combination, combinationEntered) + " right.");
                }
            }

        }

        public static bool isCorrect(int[] combination, int[] combinationEntered)
        {
            bool correct = true;
            for (int i = 0; i < combination.Length; i++)
            {
                if (combination[i] != combinationEntered[i])
                {
                    correct = false;
                }
            }
            if (correct)
                return true;
            else
                return false;
        }

        public static int numCorrect(int[] combination, int[] combinationEntered)
        {
            int numCorrect = 0;
            for (int i = 0; i < combination.Length; i++)
            {
                if (combination[i] == combinationEntered[i])
                {
                    numCorrect++;
                }
            }
            return numCorrect;
        }
    }
}
