﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodAddStrings
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Write a word!");
            string word1 = Console.ReadLine();
            Console.Write("Write another word!");
            string word2 = Console.ReadLine();

            Console.WriteLine(CombineWords(word1, word2));
        }

        public static string CombineWords(string w1, string w2)
        {
            return w1 += w2;
        }
    }
}
