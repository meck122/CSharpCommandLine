﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace MatchingGame
{
    class Program
    {
        static void Main(string[] args)
        {
            string fileName = "HighScore.txt";

            while (true)
            {
                TextReader tr = new StreamReader(fileName);
                string fileText = tr.ReadToEnd();
                Console.Write("Best Score For 26 Cards:   ");
                Console.Write(fileText + "\n");
                tr.Close();
                //number of cards
                int numOfCards;
                while (true)
                {
                    Console.Write("Enter the number of cards you'd like to play with. Enter an even amount 2-26: ");
                    string test = Console.ReadLine();

                    //checks is integer
                    bool boolTest = int.TryParse(test, out numOfCards);
                    

                    if (boolTest && numOfCards % 2 == 0 && numOfCards <= 26 && numOfCards >= 2)
                    {
                        Console.Clear();
                        break;
                    }else
                    {
                        Console.WriteLine("Invalid Amount.");
                    }
                }

                string[] cardNums = new string[numOfCards];
                string[] cardLetters = new string[numOfCards];

                for (int i = 1; i <= cardNums.Length; i++)
                {
                    cardNums[i - 1] = i.ToString();
                }

                for (int j = 0; j < cardLetters.Length; j++)
                {
                    cardLetters[j] = "+";
                }

                RandomizeCards(cardLetters, numOfCards);

                double turn = 1;

                int firstTurn = 0;
                int input = 1;

                Console.WriteLine("Turn: " + Math.Ceiling(turn / 2));
                DisplayEntire(cardNums);

                while (true)
                {
                    Console.WriteLine("\nEnter a number, it will display its secret key.");
                    string test = Console.ReadLine();
                    if (CheckValid(test, cardLetters))
                    {
                        input = Convert.ToInt32(test);
                        if (input != firstTurn)
                        {
                            Console.Clear();
                            Console.WriteLine("Turn: " + Math.Ceiling(turn / 2));
                            DisplayEntire(cardNums);
                            DisplaySpecific(input, cardLetters);
                            Console.WriteLine("");
                            if (turn % 2 != 0)
                            {
                                firstTurn = input;
                            }
                            else if (cardLetters[firstTurn - 1] == cardLetters[input - 1])
                            {
                                Console.Clear();
                                Console.WriteLine("\nTurn: " + Math.Ceiling(turn / 2));
                                DisplayEntire(cardNums);
                                DisplaySpecific2(input, firstTurn, cardLetters);
                                Console.WriteLine("\nMatch!");
                                cardLetters[firstTurn - 1] = "!";
                                cardLetters[input - 1] = "!";
                                cardNums[firstTurn - 1] = "!";
                                cardNums[input - 1] = "!";
                                if (CheckWin(cardLetters))
                                {
                                    Console.WriteLine("You win! You took " + Math.Ceiling(turn / 2) + " turns.");
                                    if (numOfCards == 26)
                                    {
                                        string[] words = fileText.Split(':');
                                        foreach (string word in words)
                                        {
                                            int highScore;
                                            bool isInt = false;
                                            isInt = int.TryParse(word, out highScore);
                                            if(Math.Ceiling(turn / 2) < highScore)
                                            {
                                                Console.WriteLine("You beat the high score! Enter your name: ");
                                                string name = Console.ReadLine();
                                                TextWriter tw = new StreamWriter(fileName);
                                                tw.WriteLine(name + "| Turns:" + Math.Ceiling(turn / 2));
                                                tw.Close();
                                                break;
                                            }
                                        }
                                    }
                                    break;
                                }
                            }
                            else
                            {
                                Console.Clear();
                                Console.WriteLine("Turn: " + Math.Ceiling(turn / 2));
                                DisplayEntire(cardNums);
                                DisplaySpecific2(input, firstTurn, cardLetters);
                                Console.WriteLine("\nNo Match!");
                            }
                            turn++;
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Invalid Input. Try Again.");
                            Console.WriteLine("\nTurn: " + Math.Ceiling(turn / 2));
                            DisplayEntire(cardNums);
                            DisplaySpecific(firstTurn, cardLetters);
                        }
                    }else
                    {
                        Console.Clear();
                        Console.WriteLine("Invalid Input. Try Again.");
                        Console.WriteLine("\nTurn: " + Math.Ceiling(turn / 2));
                        DisplayEntire(cardNums);
                        DisplaySpecific(firstTurn, cardLetters);
                    }
                }
            }
        }

        public static void DisplayEntire(string[] array)
        {
            for (int j = 0; j < array.Length; j++)
            {
                Console.Write(array[j]);
                if (j >= 9 && array[j].Length != 2)
                {
                    Console.Write("  ");
                }
                else
                {
                    Console.Write(" ");
                }
            }
        }

        public static void DisplaySpecific(int place, string[] array)
        {
            Console.WriteLine("");
            int actualPosition;
            if (place <= 10)
            {
                actualPosition = 2 * place - 3;
            }
            else
            {
                actualPosition = 3 * place - 13;
            }

            for (int i = 0; i <= actualPosition; i++)
            {
                Console.Write(" ");
            }
            Console.Write(array[place - 1]);
        }

        public static void DisplaySpecific2(int place, int place2, string[] array)
        {
            Console.WriteLine("");
            if (place > place2)
            {
                int holder = place;
                place = place2;
                place2 = holder;
            }

            int actualPosition;
            int actualPosition2;
            if (place <= 10)
            {
                actualPosition = 2 * place - 3;
            }
            else
            {
                actualPosition = 3 * place - 13;
            }

            if (place2 <= 10)
            {
                actualPosition2 = 2 * place2 - 3;
            }
            else
            {
                actualPosition2 = 3 * place2 - 13;
            }

            for (int i = 0; i <= actualPosition; i++)
            {
                Console.Write(" ");
            }

            Console.Write(array[place - 1]);

            for (int i = 0; i <= actualPosition2-actualPosition-2; i++)
            {
                Console.Write(" ");
            }

            Console.Write(array[place2 - 1]);
        }

        public static void RandomizeCards(string[] array, int numOfCards)
        {
            Random rand = new Random();
            string[] randSample = new string[numOfCards / 2];

            for (int i = 0; i < numOfCards / 2; i++)
            {
                string r = Char.ConvertFromUtf32(rand.Next(65, 91));
                if (!randSample.Contains(r))
                {
                    randSample[i] = r;
                }
                else
                {
                    i--;
                }
            }

            while (array.Contains("+"))
            {
                for (int k = 0; k < randSample.Length; k++)
                {
                    int randPos1 = rand.Next(0, array.Length);
                    int randPos2 = rand.Next(0, array.Length);
                    if ((randPos1 != randPos2) && (array[randPos1] == "+") && (array[randPos2] == "+"))
                    {
                        array[randPos1] = randSample[k];
                        array[randPos2] = randSample[k];
                    }
                    else
                    {
                        k--;
                    }
                }
            }
        }

        public static bool CheckWin(string[] array)
        {
            for(int i = 0; i < array.Length; i++)
            {
                if(array[i] != "!")
                {
                    return false;
                }
            }
            return true;
        }

        public static bool CheckValid(string test, string[] array)
        {
            char[] testArray = test.ToCharArray();
            if(test.Length == 0)
            {
                return false;
            }

            for(int i = 0; i < testArray.Length; i++)
            {
                if (!char.IsDigit(testArray[i]))
                {
                    return false;
                }
            }
            if(int.Parse(test) > array.Length || int.Parse(test) <= 0)
            {
                return false;
            }
            if(array[int.Parse(test) - 1] == "!")
            {
                return false;
            }
            return true;
        }
    }
}
