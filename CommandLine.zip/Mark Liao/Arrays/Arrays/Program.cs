﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                int sum = 0;
                int[] num = new int[5];
                for (int i = 0; i <= 4; i++)
                {
                    Console.Write("Enter an integer:");
                    num[i] = int.Parse(Console.ReadLine());
                }
                Console.WriteLine("Press enter to show sum:");
                Console.ReadLine();
                for (int j = 0; j < num.Length; j++)
                {
                    sum += num[j];
                }
                Console.WriteLine(sum);
            }
        }
    }
}
