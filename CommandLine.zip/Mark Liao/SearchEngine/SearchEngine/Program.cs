﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchEngine
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Who do you want to know about?");
                switch (Console.ReadLine().ToUpper())
                {
                    case "ETHAN":
                        Console.WriteLine("Superpower: Wear backpacks that are reasonably heavy.");
                        break;
                    case "ADAM":
                        Console.WriteLine("Superpower: Wears sunglasses.");
                        break;
                    case "MARK":
                        Console.WriteLine("Superpower: Cool.");
                        break;
                    case "JENNA":
                        Console.WriteLine("Superpower: Watches kids play games and tells them to stop.");
                        break;
                    case "ARMAN":
                        Console.WriteLine("Superpower: Has a nice jacket.");
                        break;
                    case "HENRY":
                        Console.WriteLine("Superpower: Nice looking pants.");
                        break;
                    case "JOSH":
                        Console.WriteLine("Superpower: Smelly");
                        break;
                    case "SEAN":
                        Console.WriteLine("Superpower: A semi-nice person.");
                        break;
                    case "MARCUS":
                        Console.WriteLine("Superpower: Is an okay mafia player.");
                        break;
                    case "DECLAN":
                        Console.WriteLine("Superpower: Comes prepared to camps.");
                        break;
                    default:
                        Console.WriteLine("Nope! Not here!");
                        break;
                }
            }   
        }
    }
}
