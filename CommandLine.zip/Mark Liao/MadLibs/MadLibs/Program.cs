﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MadLibs
{
    class Program
    {
        static void Main(string[] args)
        {
            String word1;
            String word2;
            String word3;
            String word4;
            String word5;
            String word6;

            Console.WriteLine("Choose an adjective.");
            word1 = Console.ReadLine();
            Console.WriteLine("Choose a noun.");
            word2 = Console.ReadLine();
            Console.WriteLine("Choose an adjective.");
            word3 = Console.ReadLine();
            Console.WriteLine("Choose an noun.");
            word4 = Console.ReadLine();
            Console.WriteLine("Choose an adjective.");
            word5 = Console.ReadLine();
            Console.WriteLine("Choose an noun.");
            word6 = Console.ReadLine();

            Console.WriteLine("The " + word1 + " " + word2 + " went to the park.");
            Console.WriteLine("At the park was a " + word3 + " " + word4 + ".");
            Console.WriteLine("Then they went home and ate a " + word5 + " " + word6 + ".");

        }
    }
}
