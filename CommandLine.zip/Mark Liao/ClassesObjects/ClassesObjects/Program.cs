﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesObjects
{
    class Program
    {
        static void Main(string[] args)
        {
            Hand leftHand = new Hand();
            leftHand.name = "Left Hand";
            leftHand.numberOfFingers = 12;
            leftHand.pinkieLength = 86.6f;
            leftHand.isClean = true;
            
            Console.WriteLine(leftHand.name);
            Console.WriteLine("Number of fingers: " + leftHand.numberOfFingers);
            Console.WriteLine("Pinkie length: " + leftHand.pinkieLength + "in.");
            Console.WriteLine("Is Clean? " + leftHand.isClean);

            Hand weirdHand = new Hand("hello", 17, 24, false);

            Console.WriteLine("\n\n\nName: " + weirdHand.name);
            Console.WriteLine("Number of fingers: " + weirdHand.numberOfFingers);
            Console.WriteLine("Pinkie length: " + weirdHand.pinkieLength + "in.");
            Console.WriteLine("Is Clean? " + weirdHand.isClean);
        }
    }
}
