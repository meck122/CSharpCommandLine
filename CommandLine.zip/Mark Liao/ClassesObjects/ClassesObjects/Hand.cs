﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesObjects
{
    class Hand
    {
        public string name { get; set; }
        public int numberOfFingers { get; set; }
        public float pinkieLength { get; set; } //inches
        public bool isClean { get; set; } 

        public Hand()
        {
            name = "YOU DIDN'T SPECIFY WHICH HAND";
            numberOfFingers = -201;
            pinkieLength = -98;
            isClean = false;
        }

        public Hand(string _name, int _numberOfFingers, float _pinkieLength, bool _isClean)
        {
            name = _name;
            numberOfFingers = _numberOfFingers;
            pinkieLength = _pinkieLength;
            isClean = _isClean;
        }

    }
}
