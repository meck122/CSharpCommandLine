﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeNumberGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isPrime = true;
            int limit = int.Parse(Console.ReadLine());
            for (int i = 2; i <= limit; i++) {
                isPrime = true;
                for (int n = 2; n <= Math.Sqrt(i); n++)
                {
                    if (i % n == 0)
                    {
                        isPrime = false;
                        break;
                    }
                }
                //You could just start with i = 1 and not have to check as many conditions. - Henry
                if (isPrime)
                {
                    Console.WriteLine(i);
                }
            }
            
        }
    }
}
