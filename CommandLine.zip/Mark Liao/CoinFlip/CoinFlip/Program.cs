﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoinFlip
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                DoCoinFlip();
            }
        }

        public static void DoCoinFlip()
        {
            CheckCoinFlip(GetGuess(), FlipCoin());
        }

        public static int FlipCoin()
        {
            Random r = new Random();
            return r.Next(1, 3);
        }

        public static string GetGuess()
        {
            Console.Write("Guess: Heads (H) or Tails? (T)");
            return Console.ReadLine();
        }

        public static void CheckCoinFlip(string guess, int randNum)
        {
            if (randNum == 1)
                Console.WriteLine("Heads!");
            else
                Console.WriteLine("Tails!");

            if ((guess.ToUpper() == "H" && randNum == 1) || (guess.ToUpper() == "T" && randNum == 0))
            {
                Console.WriteLine("You were right!");
            }
            else
            {
                Console.WriteLine("You were wrong!");
            }
        }
    }
}
