﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hangman
{
    class Program
    {
        static void Main(string[] args)
        {
            //chooses random word from txt file
            string wordChosen = ChooseWord();
            //Console.WriteLine(wordChosen);

            //writes words letter to char array
            char[] letters = wordChosen.ToCharArray();

            //new char array for the correct letters
            char[] correctLettersGuessed = new char[letters.Length * 2];

            //string that displays wrong answers
            string strWrongGuesses = "";

            //num of wrong guesses
            int wrongGuesses = 0;

            bool play = false;

            //tells user to guess a letter
            Console.Write("Guess a letter: ");

            //creates display for word with underscores and spaces
            CreateBlanks(correctLettersGuessed);

            //displays blanks, number of wrong guesses, and the letters that were guessed
            Display(correctLettersGuessed, wrongGuesses, strWrongGuesses);

            //displays the hanging art stuff
            DisplayGraphics(wrongGuesses);

            //if player is playing:
            while (!play)
            {
                //defaults the player to having a wrong guess
                bool isWrong = true;

                //brings user input to a test variable to confirm validity
                string test = Console.ReadLine();

                //instantiates input
                char input = ' ';

                //if valid:
                if (!CheckInvalid(test))
                {
                    //input is now test
                    input = char.Parse(test.ToLower());

                    //if word hasn't been a previous wrong guess:
                    if (CheckPrior(strWrongGuesses, input))
                    {
                        //checks if input matches any letters of the answer
                        for (int i = 0; i < letters.Length; i++)
                        {
                            if (input == letters[i])
                            {
                                correctLettersGuessed[i * 2 + 1] = input;
                                isWrong = false;
                            }
                        }

                        if (isWrong)
                        {
                            strWrongGuesses += " " + input;
                            wrongGuesses++;
                        }

                        Console.Clear();

                        Display(correctLettersGuessed, wrongGuesses, strWrongGuesses);
                        DisplayGraphics(wrongGuesses);

                        if (wrongGuesses >= 11)
                        {
                            play = false;
                            Console.WriteLine("You lost! The word was: " + wordChosen);
                        }

                        if (CheckWin(correctLettersGuessed))
                        {
                            play = false;
                            Console.WriteLine("You Win!");
                        }
                    }
                    else
                    {
                        Console.WriteLine("You've already guessed that letter.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Try Again.");
                }

            }
        }

        public static void CreateBlanks(char[] correctLettersGuessed)
        {
            for (int i = 0; i < correctLettersGuessed.Length; i++)
            {
                if (i % 2 == 0)
                {
                    correctLettersGuessed[i] = ' ';
                }
                else
                {
                    correctLettersGuessed[i] = '_';
                }
            }
        }

        public static bool CheckInvalid(string test)
        {
            if (test.Length == 1)
            {
                if (!char.IsLetter(char.Parse(test)))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        public static string ChooseWord()
        {
            string fileName = "Words.txt";
            Random rand = new Random();
            TextReader tr = new StreamReader(fileName);
            string word = File.ReadLines(fileName).Skip(rand.Next(1, 58110)).Take(1).First();
            tr.Close();
            return word;
        }

        public static void Display(char[] correctLettersGuessed, int wrongGuesses, string strWrongGuesses)
        {
            for (int j = 0; j < correctLettersGuessed.Length; j++)
            {
                Console.Write(correctLettersGuessed[j]);
            }
            Console.WriteLine("\nNumber of Wrong Guesses: " + wrongGuesses);
            Console.WriteLine("Wrong Guesses:" + strWrongGuesses);
        }

        public static bool CheckWin(char[] correctLettersGuessed)
        {
            for (int k = 0; k < correctLettersGuessed.Length; k++)
            {
                if (correctLettersGuessed[k] == '_')
                {
                    return false;
                }
            }
            return true;
        }

        public static bool CheckPrior(string str, char input)
        {
            if (str.Contains(input.ToString()))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static void DisplayGraphics(int guesses)
        {
            if (guesses == 0)
            {
                Console.WriteLine("________    ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|           ");
                Console.WriteLine("|           ");
                Console.WriteLine("|           ");
                Console.WriteLine("|           ");
                Console.WriteLine("|_________  ");
            }
            else
            if (guesses == 1)
            {
                Console.WriteLine("________    ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|      O    ");
                Console.WriteLine("|           ");
                Console.WriteLine("|           ");
                Console.WriteLine("|           ");
                Console.WriteLine("|_________  ");
            }
            else
            if (guesses == 2)
            {
                Console.WriteLine("________    ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|      O    ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|           ");
                Console.WriteLine("|           ");
                Console.WriteLine("|_________  ");
            }
            else
            if (guesses == 3)
            {
                Console.WriteLine("________    ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|      O    ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|           ");
                Console.WriteLine("|_________  ");
            }
            else
            if (guesses == 4)
            {
                Console.WriteLine("________    ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|      O    ");
                Console.WriteLine("|      |/   ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|           ");
                Console.WriteLine("|_________  ");
            }
            else
            if (guesses == 5)
            {
                Console.WriteLine("________    ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|      O    ");
                Console.WriteLine("|     \\|/   ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|           ");
                Console.WriteLine("|_________  ");
            }
            else
            if (guesses == 6)
            {
                Console.WriteLine("________    ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|      O    ");
                Console.WriteLine("|     \\|/   ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|     /     ");
                Console.WriteLine("|_________  ");
            }
            else
            if (guesses == 7)
            {
                Console.WriteLine("________    ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|      O    ");
                Console.WriteLine("|     \\|/   ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|     / \\  ");
                Console.WriteLine("|_________  ");
            }
            else
            if (guesses == 8)
            {
                Console.WriteLine("________    ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|      O .  ");
                Console.WriteLine("|     \\|/   ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|     / \\  ");
                Console.WriteLine("|_________  ");
            }
            else
            if (guesses == 9)
            {
                Console.WriteLine("________    ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|    . O .  ");
                Console.WriteLine("|     \\|/   ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|     / \\  ");
                Console.WriteLine("|_________  ");
            }
            else
            if (guesses == 10)
            {
                Console.WriteLine("________    ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|    . O .  ");
                Console.WriteLine("|     \\|/   ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|     / \\  ");
                Console.WriteLine("|        b   ");
                Console.WriteLine("|__________  ");
            }
            else
            if (guesses == 11)
            {
                Console.WriteLine("________    ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|    . O .  ");
                Console.WriteLine("|     \\|/   ");
                Console.WriteLine("|      |    ");
                Console.WriteLine("|     / \\  ");
                Console.WriteLine("|    d   b   ");
                Console.WriteLine("|__________  ");
            }
        }
    }
}
