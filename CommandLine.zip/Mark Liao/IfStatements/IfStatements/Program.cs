﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IfStatements
{
    class Program
    {
        static void Main(string[] args)
        {
            int highScore = 100;
            int highScore2 = 95;
            int highScore3 = 90;
            int test;
            while (true) {
                Console.WriteLine("Write your score!");
                test = int.Parse(Console.ReadLine());
                if (test > highScore)
                {
                    highScore = test;
                    Console.WriteLine("New high score: " + highScore);
                }
                else if(test > highScore2)
                {
                    highScore2 = test;
                    Console.WriteLine("New 2nd high score: " + highScore2);
                }
                else if(test > highScore3)
                {
                    highScore3 = test;
                    Console.WriteLine("New 3rd high score: " + highScore3);
                }else
                {
                    Console.WriteLine("You did not make leaderboard.");
                }
            }
        }
    }
}