﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculater
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number:");
            float num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Number:");
            float num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Sum: " + (num1 + num2));
            Console.WriteLine("Difference: " + (num1 - num2));
            Console.WriteLine("Product: " + (num1 * num2));

            float quotient = num1 / num2;

            Console.WriteLine("Quotient: " + quotient);
        }
    }
}
