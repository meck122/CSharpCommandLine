﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeBreakGame
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Would you like to write the code? (Y) (N)");

            //if(Console.ReadLine().ToUpper() == "Y")
            //{
            //    Console.WriteLine("Okay, write your code. Integers only.");
            //}
            Console.WriteLine("How many digits?");
            int digits = int.Parse(Console.ReadLine());
            Random rand = new Random();
            char[] combinationEntered = new char[4];
            int[] combination = new int[digits];

            for(int i = 0; i < combination.Length; i++)
            {
                combination[i] = rand.Next(0, 10);
            }

            while (true)
            {
                Console.Write("Enter number:");
                string input = (Console.ReadLine());
                if (input.Length == digits)
                {
                    combinationEntered = input.ToString().ToCharArray();
                    if (isCorrect(combination, combinationEntered))
                    {
                        Console.WriteLine("You are correct!");
                    }
                    else
                    {
                        Console.WriteLine("You are wrong. You got " + numCorrect(combination, combinationEntered) + " right.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid!");
                }
            }
        }

        public static bool isCorrect(int[] combination, char[] combinationEntered)
        {
            bool correct = true;
            for (int i = 0; i < combination.Length; i++)
            {
                if (combination[i] != int.Parse(combinationEntered[i].ToString()))
                {
                    correct = false;
                }
            }
            if (correct)
                return true;
            else
                return false;
        }

        public static int numCorrect(int[] combination, char[] combinationEntered)
        {
            int numCorrect = 0;
            for (int i = 0; i < combination.Length; i++)
            {
                if (combination[i] == int.Parse(combinationEntered[i].ToString()))
                {
                    numCorrect++;
                }
            }
            return numCorrect;
        }
    }
}

